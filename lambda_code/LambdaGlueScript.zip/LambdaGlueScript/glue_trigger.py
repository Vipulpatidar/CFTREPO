import json
import boto3

glue_client = boto3.client('glue')

# Replace with your Glue job name
GLUE_JOB_NAME = "Glue_dac"

def lambda_handler(event, context):
    # Extract the file name from S3 event
    try:
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        object_key = event['Records'][0]['s3']['object']['key']

        
        path = f"s3://{bucket_name}/{object_key}"

        print(f"✅ New File Detected: {object_key} at {path}")
        input_paths = {"--PATH": path}

        print("The file paths are recieved")
        if "dac" in path:
            response = glue_client.start_job_run(
            JobName='Glue_dac',
            Arguments=input_paths
            )
            print("The glue job is starting")
            return {
                'statusCode': 200,
                'body': f"Glue job started: {response['JobRunId']}"
        }
        else:
            response = glue_client.start_job_run(
            JobName='Glue_dbda',
            Arguments=input_paths
            )
            print("The glue job is starting")
            return {
                'statusCode': 200,
                'body': f"Glue job started: {response['JobRunId']}"}

        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error starting Glue job: {str(e)}")
        }
